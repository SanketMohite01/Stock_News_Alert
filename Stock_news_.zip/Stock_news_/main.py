import requests
from twilio.rest import Client

STOCK_NAME = "TSLA"
COMPANY_NAME = "Tesla Inc"

STOCK_ENDPOINT = "https://www.alphavantage.co/query"
NEWS_ENDPOINT = "https://newsapi.org/v2/everything"

stock_api = "BDL0HIZ1U4QS1411"
news_api = "ed2b0e7ff46c4207b3626b1131949322"

# --- STEP 1: Get Stock Data ---
stock_param = {
    "function": "TIME_SERIES_DAILY",
    "symbol": STOCK_NAME,
    "apikey": stock_api,
}

response = requests.get(STOCK_ENDPOINT, params=stock_param)
stock_data = response.json()

if "Time Series (Daily)" not in stock_data:
    print("❌ Error: 'Time Series (Daily)' not found. Check API limit or key.")
    print("🔍 Response:", stock_data)
    exit()

data = stock_data["Time Series (Daily)"]
data_list = [value for (key, value) in data.items()]
yesterday_data = data_list[0]
yesterday_close = float(yesterday_data["4. close"])

day_before_data = data_list[1]
day_before_close = float(day_before_data["4. close"])

print(f"✅ Yesterday: ${yesterday_close}")
print(f"✅ Day Before Yesterday: ${day_before_close}")

# --- STEP 2: Calculate Difference ---
diff = abs(yesterday_close - day_before_close)
diff_percent = round((diff / yesterday_close) * 100)

direction = "🔺" if yesterday_close > day_before_close else "🔻"
print(f"📊 Difference: {direction}{diff_percent}%")

# --- STEP 3: Get News if % Change > 0 ---
if diff_percent > 0:
    news_param = {
        "apiKey": news_api,
        "qInTitle": COMPANY_NAME,
    }
    news_response = requests.get(NEWS_ENDPOINT, params=news_param)
    news_data = news_response.json()

    if "articles" not in news_data:
        print("❌ Error: News articles not found.")
        print("🔍 Response:", news_data)
        exit()

    articles = news_data["articles"]
    top_3_articles = articles[:3]

    formatted_articles = [
        f"{STOCK_NAME}: {direction}{diff_percent}%\n"
        f"Headline: {article['title']}\n"
        f"Brief: {article['description']}"
        for article in top_3_articles
    ]

    # --- STEP 4: Send via WhatsApp (Twilio) ---
    send_whatsapp = True

    if send_whatsapp:
        account_sid = "AC85eb2383aace806f65eadbe288be51e7"
        auth_token = "9755ef3a8820c09be452d7aec4df01a8"
        client = Client(account_sid, auth_token)

        for msg in formatted_articles:
            message = client.messages.create(
                from_='whatsapp:+14155238886',
                to='whatsapp:+917304141618',  # Replace with your verified number
                body=msg
            )
            print(f"✅ WhatsApp Message sent! SID: {message.sid}")
    else:
        print("ℹ️ WhatsApp alert is disabled.")
else:
    print("ℹ️ Stock change not significant. No news fetched.")
